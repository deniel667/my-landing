﻿export default function VoiceSection() {
  return (
    <section id="voice" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-6xl mx-auto text-left">
        <div className="section-head">
          <p className="section-kicker text-[10px] uppercase tracking-[0.3em] text-text-secondary">V O I C E / 導入店舗・体験者の声</p>
          <h2 className="section-title font-serif text-3xl">導入後の現場で実感された変化</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <blockquote className="fade-in-block border border-line bg-white p-7">
            <p className="font-serif text-lg leading-relaxed text-text">「導入の意図がメニュー上で伝わるようになった」</p>
            <footer className="mt-5 text-xs tracking-[0.2em] uppercase text-text-secondary">Restaurant Owner</footer>
          </blockquote>

          <blockquote className="fade-in-block border border-line bg-white p-7">
            <p className="font-serif text-lg leading-relaxed text-text">「スタッフが無理なく説明でき、現場で回る設計になった」</p>
            <footer className="mt-5 text-xs tracking-[0.2em] uppercase text-text-secondary">Hotel F&amp;B Manager</footer>
          </blockquote>
        </div>

        <div className="mt-6 fade-in-block border border-line bg-white p-7">
          <p className="font-serif text-lg leading-relaxed text-text">「ゲストに違いが伝わり、注文につながる体験になった」</p>
          <footer className="mt-5 text-xs tracking-[0.2em] uppercase text-text-secondary">Sommelier Team</footer>
        </div>
      </div>
    </section>
  );
}
