﻿'use client';

import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';

export default function StorySection() {
  const rootRef = useRef<HTMLElement | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const node = rootRef.current;
    if (!node || isVisible) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (!entry?.isIntersecting) return;
        setIsVisible(true);
        observer.disconnect();
      },
      {
        threshold: 0.18,
        rootMargin: '0px 0px -12% 0px',
      }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [isVisible]);

  return (
    <section ref={rootRef} className={`story-layout ${isVisible ? 'is-visible' : ''}`}>
      <span className="story-top-rule" aria-hidden="true" />

      <header className="story-head">
        <p className="story-eyebrow">S T O R Y / 生 産 者 の 覚 悟</p>
        <h2 className="story-title">「『売り方』ではなく、人生をかけて造られた一本を」</h2>
      </header>

      <div className="grid12 story-grid">
        <div className="story-main prose story-reveal story-delay-0">
          <p>それぞれのワイナリーには、長い歴史があります。成功だけでなく、失敗や葛藤、自然の厳しさと向き合いながら、命を削るようにして造られてきたワインがあります。</p>
          <p>FINDESTが選ぶ基準は、市場の都合や流行ではありません。造り手が自らの哲学で積み上げてきた品質と、そのワインが宿す背景です。</p>
          <p>「FINDESTは、それぞれの生産者の背景や想い、秘話を、長年の関係性を経て知っているからこそ、<span className="story-ink-underline">その”熱量”ごと、次の表現者へつなぐ役割</span>を担っています。</p>
        </div>

        <aside className="story-side story-reveal story-delay-1">
          <figure className="story-photo-card">
            <div className="story-photo-frame">
              <Image
                src="/story/story-main-president.jpg"
                alt="生産者の佇まい"
                fill
                className="object-cover"
                sizes="(min-width: 1024px) 34vw, 100vw"
              />
            </div>
            <figcaption className="story-caption">
              <p className="story-caption-kicker">VINEYARD / 畑</p>
              <p className="story-caption-text">畑の光と風</p>
            </figcaption>
          </figure>
        </aside>

        <div className="story-bottom-block story-reveal story-delay-2">
          <span className="story-bottom-divider" aria-hidden="true" />
          <figure className="story-bottom-figure">
            <div className="story-bottom-media">
              <Image
                src="/story/story-trip-collage.jpg"
                alt="セラーで熟成されるワイン"
                fill
                className="story-bottom-image object-cover"
                sizes="(min-width: 1024px) 100vw, 100vw"
              />
            </div>
            <figcaption className="story-caption story-caption-wide">
              <p className="story-caption-kicker">CELLAR / 樽</p>
              <p className="story-caption-text">静かに熟成する時間</p>
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}
