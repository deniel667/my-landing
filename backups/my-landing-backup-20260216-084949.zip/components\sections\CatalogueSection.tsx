﻿import Image from 'next/image';

const wineries = [
  { id: 'dautel', name: 'Weingut Dautel', region: 'Wurttemberg', photo: '/wineries/dautel-new.jpg', imageClass: 'object-cover', href: '#contact' },
  { id: 'horst', name: 'Weingut Horst Sauer', region: 'Franken', photo: '/wineries/horst-sauer-new.jpg', imageClass: 'object-cover', href: '#contact' },
  { id: 'landerer', name: 'Weingut Landerer', region: 'Baden', photo: '/wineries/landerer-new.jpg', imageClass: 'object-cover', href: '#contact' },
  { id: 'ludwig', name: 'Weingut Ludwig', region: 'Mosel', photo: '/wineries/ludwig-new.jpg', imageClass: 'object-cover', href: '#contact' },
  { id: 'hamm', name: 'Weingut Hamm', region: 'Rheingau', photo: '/wineries/hamm-new.jpg', imageClass: 'object-cover object-[45%_30%]', href: '#contact' },
  { id: 'bus', name: 'Weingut Bus', region: 'Pfalz', photo: '/wineries/bus-new.jpg', imageClass: 'object-cover', href: '#contact' },
  { id: 'ress', name: 'Weingut Ress', region: 'Rheingau', photo: '/wineries/ress-new.jpg', imageClass: 'object-cover', href: '#contact' },
  { id: 'salwey', name: 'Weingut Salwey', region: 'Baden', photo: '/wineries/salwey-new.jpg', imageClass: 'object-cover object-[50%_38%]', href: '#contact' },
  { id: 'stodden', name: 'Weingut Jean Stodden', region: 'Ahr', photo: '/wineries/jean-stodden-new.jpg', imageClass: 'object-cover object-[50%_42%]', href: '#contact' },
] as const;

export default function CatalogueSection() {
  return (
    <section className="wineries-layout">
      <header className="wineries-head">
        <p className="section-kicker">W I N E R I E S</p>
        <h2 className="section-title-mincho">ワイナリー一覧</h2>
        <div className="prose">
          <p>業務用導入（飲食・ホテル・酒販）に対応し、導入条件に合わせてご提案します。</p>
          <p>取扱いワイナリー一覧・導入イメージをPDFでお送りします。</p>
        </div>
      </header>

      <div className="wineries-grid">
        {wineries.map((winery) => (
          <article key={winery.id} className="winery-card">
            <div className="winery-card-image">
              <Image src={winery.photo} alt={winery.name} fill className={winery.imageClass} sizes="(min-width: 1024px) 31vw, (min-width: 680px) 47vw, 100vw" />
            </div>

            <div className="winery-card-body">
              <h3>{winery.name}</h3>
              <p>{winery.region}</p>
            </div>

            <div className="winery-card-footer">
              <a href={winery.href}>VIEW MORE</a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
