﻿'use client';

import { site } from '../data/my-landing/site';
import HeroSection from '../components/sections/HeroSection';
import NorenSlitDivider from '../components/NorenSlitDivider';
import PhilosophySection from '../components/sections/PhilosophySection';
import NorenNetworkSection from '../components/sections/NorenNetworkSection';
import TrustSection from '../components/sections/TrustSection';
import ServiceSection from '../components/sections/ServiceSection';
import StorySection from '../components/sections/StorySection';
import CatalogueSection from '../components/sections/CatalogueSection';
import ContactSection from '../components/sections/ContactSection';
import FooterSection from '../components/sections/FooterSection';
import Section from '../components/Section';

function TopNav() {
  const links = [
    ['#philosophy', 'Philosophy'],
    ['#noren-network', 'Network'],
    ['#rare', '0.2%'],
    ['#story', 'Story'],
    ['#service', 'Service'],
    ['#catalogue', 'Wineries'],
    ['#contact', 'Contact'],
  ] as const;

  return (
    <nav className="site-nav">
      <div className="shell nav-inner">
        <a href="#hero" className="brand-mark" aria-label="FINDEST top">
          <span className="brand-main">FINDEST</span>
          <span className="brand-sub">German Wine Curation</span>
        </a>
        <div className="nav-links">
          {links.map(([href, label]) => (
            <a key={href} href={href} className="nav-link">
              {label}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}

export default function Page() {
  return (
    <main className="site-main">
      <TopNav />
      <HeroSection data={site.hero} />
      <NorenSlitDivider id="slit-hero-philosophy" />
      <Section id="philosophy" variant="full">
        <PhilosophySection />
      </Section>
      <Section id="noren-network" variant="full">
        <NorenNetworkSection />
      </Section>
      <Section id="rare" variant="full">
        <TrustSection />
      </Section>
      <Section id="story" variant="full">
        <StorySection />
      </Section>
      <Section id="service" variant="editorial">
        <ServiceSection />
      </Section>
      <Section id="catalogue" variant="full">
        <CatalogueSection />
      </Section>
      <NorenSlitDivider id="slit-before-contact" />
      <Section id="contact" variant="full">
        <ContactSection />
      </Section>
      <FooterSection />
    </main>
  );
}
