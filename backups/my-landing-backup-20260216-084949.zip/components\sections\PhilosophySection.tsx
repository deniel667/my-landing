'use client';

import SideNavIndicator from '../SideNavIndicator';

type PhilosophyBlock = {
  id: string;
  index: string;
  menu: string;
  title: string;
  body: string;
};

const blocks: PhilosophyBlock[] = [
  {
    id: 'philosophy-1',
    index: '01',
    menu: '① 理念',
    title: '① 理念',
    body: `FINDESTと関わるすべての場には、
共通する理念があります。

それは、

品位と丁寧さを守ること。
そして、自分軸を尊重すること。

その理念を、
私たちは二つの言葉で表しています。

⸻

Sustainable Integrity
（品位と丁寧さを守る）
×
Honoring Identity
（自分軸を尊重）

⸻`,
  },
  {
    id: 'philosophy-2',
    index: '02',
    menu: '② 目的',
    title: '② 目的',
    body: `FINDESTは、関わる場や人々において
• 近視眼的な消費や他人軸の評価に影響されていることに気付く
• 本質と向き合う姿勢を取り戻す
• 自分の感覚で受け取る
このようなステイタスを作り出し

ワインを通した文化的姿勢の再設計を目指しています。

⸻`,
  },
  {
    id: 'philosophy-3',
    index: '03',
    menu: '③ 共鳴',
    title: '③ 共鳴',
    body: `FINDESTは、共鳴します。

志を持つ人、
自分軸を大切にする姿勢。

そこに共鳴したとき、
私たちはワインを重ねます。`,
  },
  {
    id: 'philosophy-4',
    index: '04',
    menu: '④ 構造',
    title: '④ 構造',
    body: `品位と丁寧さを守り
自分軸を尊重するために
私たちは構造ある適応を選びます。
→ Structured Adaptation

それは、無秩序な拡大ではなく、
関係性に応じて深度を整えていくものです。`,
  },
  {
    id: 'philosophy-5',
    index: '05',
    menu: '⑤ 暖簾',
    title: '⑤ 暖簾という発想～深度が深まった関係性～',
    body: `日本文化の【暖簾 ～Noren～】に着想を得て、
私たちは近視眼的ではなく、
品位と軸を保ちながら展開するスタイルを取り入れました。

暖簾分けとは本来、
本家の信用（屋号）を預けられる相手にだけ、
営業の権利と責任を分ける日本の商慣行です。

FINDESTがここから学ぶのは、
“数を増やす”ことだけではなく、
浅い理解で価値を崩さないための「型（約束事）」を共有することです。

この暖簾システムは、後述の【公認パートナー】に適用されます。`,
  },
];

export default function PhilosophySection() {
  return (
    <section className="editorial-section philosophy-layout" aria-label="PHILOSOPHY / 理念">
      <div className="grid12 editorial-grid">
        <aside className="editorial-side">
          <p className="section-kicker">P H I L O S O P H Y</p>
          <h2 className="section-title-mincho">理念</h2>
          <SideNavIndicator
            items={blocks.map((block) => ({
              id: block.id,
              label: `${block.index} ${block.menu}`,
            }))}
            className="side-nav"
          />
        </aside>

        <div className="editorial-main">
          {blocks.map((block) => (
            <article key={block.id} id={block.id} className="editorial-panel philosophy-panel">
              <h3 className="editorial-panel-title">{block.title}</h3>
              <p className="philosophy-preline">{block.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
