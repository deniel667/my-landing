﻿import type { HeroData } from '@/data/my-landing/site';

type Props = { data: HeroData };

export default function HeroSection({ data }: Props) {
  return (
    <header id="hero" className="hero-noren">
      <div className="hero-noren-bg" aria-hidden="true">
        <span className="hero-layer hero-base" />
        <span className="hero-layer hero-folds" />
        <span className="hero-layer hero-grain" />
        <span className="hero-layer hero-vignette" />
        <span className="hero-layer hero-slit-core" />
        <span className="hero-layer hero-slit-glow" />
      </div>

      <div className="container hero-grid-wrap">
        <div className="grid12 hero-grid">
          <div className="hero-content-block">
            <div className="hero-micro-haze">
              <p className="hero-kicker-small">Dark Noren / Entrance</p>
              <p className="hero-kicker">{data.eyebrow}</p>
              <h1 className="hero-title">
                <span>{data.lead[0]}</span>
                <span>{data.lead[1]}</span>
                <span>{data.lead[2]}</span>
              </h1>
              <p className="hero-subcopy">{data.sub}</p>
              <div className="hero-actions">
                <a href={data.ctas[0].href} className="cta-button cta-button-paper hero-action-button hero-action-primary">
                  {data.ctas[0].label}
                </a>
                <a href={data.ctas[1].href} className="cta-button cta-button-ghost hero-action-button hero-action-secondary">
                  {data.ctas[1].label}
                </a>
              </div>
              <p className="hero-note">{data.note}</p>
            </div>
          </div>
          <div className="hero-negative-space" aria-hidden="true" />
        </div>
      </div>
    </header>
  );
}
