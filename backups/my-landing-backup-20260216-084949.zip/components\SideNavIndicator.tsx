﻿'use client';

import { useEffect, useState } from 'react';

type SideNavItem = {
  id: string;
  label: string;
};

type Props = {
  items: SideNavItem[];
  className?: string;
};

export default function SideNavIndicator({ items, className }: Props) {
  const [activeId, setActiveId] = useState(items[0]?.id ?? '');

  useEffect(() => {
    if (!items.length) return;

    const elements = items
      .map((item) => document.getElementById(item.id))
      .filter((el): el is HTMLElement => Boolean(el));

    if (!elements.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

        if (!visible.length) return;
        setActiveId(visible[0].target.id);
      },
      {
        rootMargin: '-30% 0px -60% 0px',
        threshold: [0.2, 0.45, 0.7],
      }
    );

    elements.forEach((element) => observer.observe(element));

    return () => observer.disconnect();
  }, [items]);

  return (
    <nav className={className} aria-label="Section indicator">
      <ul className="side-nav-list">
        {items.map((item) => {
          const isActive = activeId === item.id;

          return (
            <li key={item.id} className={`side-nav-item ${isActive ? 'is-active' : ''}`}>
              <span className="side-nav-dot" aria-hidden="true" />
              <span>{item.label}</span>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
