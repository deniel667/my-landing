type Tier = {
  title: string;
  micro: string;
  bullets: string[];
  note?: string;
  tierClass: string;
};

const tiers: Tier[] = [
  {
    title: '0.2% / 最高評価クラス',
    micro: 'TOP CLASS',
    bullets: ['ドイツの中でも、約0.2%の最高評価クラス'],
    note: '※五つ星評価：Eichelmann『Deutschlands Weine』（該当年度版）を参照。',
    tierClass: 'trust-tier-top',
  },
  {
    title: 'VDP / 厳格な基準',
    micro: 'QUALITY ASSOCIATION',
    bullets: [
      '取り扱い生産者の多くは、ドイツ高品質辛口ワイン協会VDP（Verband Deutscher Prädikatsweingüter）に所属。',
      'VDPは、畑・収穫量・醸造・品質基準において厳格な基準を設ける組織です。',
    ],
    tierClass: 'trust-tier-upper',
  },
  {
    title: 'Selection / 選定の思想',
    micro: 'CURATION LOGIC',
    bullets: ['「流通の都合」ではなく、畑・収穫・醸造の哲学と品質基準で選び抜いています。'],
    tierClass: 'trust-tier-middle',
  },
  {
    title: 'Operation / 現場で回る',
    micro: 'FIELD OPERATION',
    bullets: [
      '品質の一貫性と、導入後に“現場で回る”ことまで見据えて選定しています。',
      'FINDESTの基準は、流行ではなく“品質の再現性”と“導入後に回ること”。',
      '料理・客層・価格帯などの条件に合わせてご提案します',
    ],
    tierClass: 'trust-tier-base',
  },
];

function PyramidTier({ title, micro, bullets, note, tierClass }: Tier) {
  return (
    <article className={`trust-tier ${tierClass}`}>
      <header className="trust-tier-head">
        <h3>{title}</h3>
        <p>{micro}</p>
      </header>
      <ul className="trust-tier-list">
        {bullets.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
      {note ? <p className="trust-tier-note">{note}</p> : null}
    </article>
  );
}

export default function TrustSection() {
  return (
    <section className="trust-layout">
      <header className="trust-head">
        <p className="section-kicker">T R U S T / 世 界 基 準</p>
        <h2 className="section-title-mincho">世界基準で評価される、ドイツ高品質ワイン</h2>
        <p className="trust-intro">FINDESTが扱うのは、世界的に評価の高いドイツの造り手による高品質ワインです。</p>
      </header>

      <div className="grid12 trust-grid">
        <div className="trust-left">
          <div className="trust-pyramid">
            {tiers.map((tier) => (
              <PyramidTier key={tier.title} {...tier} />
            ))}
          </div>
        </div>

        <aside className="trust-stat-card">
          <p className="trust-stat-number">0.2%</p>
          <p className="trust-stat-copy">ドイツの中でも、約0.2%の最高評価クラス</p>
          <p className="trust-note">※「約0.2%」は当社定義の「ワイナリー（Weingut）」母数に基づく概算です（当社算出）。</p>
        </aside>

        <div className="trust-cta-row">
          <a href="#contact" className="cta-button cta-button-ink">資料請求（PDF）</a>
          <a href="#contact" className="cta-button trust-cta-secondary">導入相談</a>
          <p className="trust-helper">※ 原則1営業日以内に返信いたします</p>
        </div>
      </div>
    </section>
  );
}
