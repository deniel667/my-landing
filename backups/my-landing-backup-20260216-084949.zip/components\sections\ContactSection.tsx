export default function ContactSection() {
  return (
    <div className="contact-layout-section">
      <div className="contact-bg-layer" aria-hidden="true" />

      <header className="contact-head">
        <p className="contact-eyebrow">CONTACT</p>
        <h2 className="contact-title">まずは、状況をお聞かせください</h2>
        <div className="contact-support">
          <p className="contact-subtext">業務用導入（飲食・ホテル・酒販）に対応し、導入条件に合わせてご提案します。</p>
          <p className="contact-subtext">取扱いワイナリー一覧・導入イメージをPDFでお送りします。</p>
        </div>
      </header>

      <form className="contact-form-shell contact-form-grid">
        <div className="contact-row-grid">
          <label className="contact-field">
            <span>担当者名</span>
            <input type="text" />
          </label>
          <label className="contact-field">
            <span>店名 / 会社名</span>
            <input type="text" />
          </label>
        </div>

        <div className="contact-row-grid">
          <label className="contact-field">
            <span>Email</span>
            <input type="email" />
          </label>
          <label className="contact-field">
            <span>業態</span>
            <select>
              <option>飲食</option>
              <option>ホテル</option>
              <option>酒販</option>
            </select>
          </label>
        </div>

        <label className="contact-field">
          <span>お問い合わせ内容</span>
          <textarea rows={7} />
        </label>

        <div className="contact-submit-row">
          <button type="submit" className="cta-button cta-button-ink">送信する</button>
        </div>
      </form>
    </div>
  );
}
