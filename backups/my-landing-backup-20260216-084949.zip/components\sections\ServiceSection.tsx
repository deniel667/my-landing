﻿import Image from 'next/image';

const definitions = [
  ['想い', '何を大切にしているか、誰に届けたいか'],
  ['空間', '光・音・温度・距離感'],
  ['料理', '味の輪郭、余韻、ペアリングの狙い'],
  ['人', '提供者の言葉と所作（無理なく伝わる形）'],
] as const;

const results = [
  '— 導入の意図がメニュー上で伝わる',
  '— スタッフが無理なく説明でき、現場で回る',
  '— ゲストに違いが伝わり、注文につながる',
] as const;

export default function ServiceSection() {
  return (
    <section className="service-layout">
      <span className="service-top-rule" aria-hidden="true" />

      <header className="service-head">
        <p className="section-kicker">S E R V I C E / 提 案</p>
      </header>

      <div className="grid12 service-grid">
        <div className="service-main">
          <h2 className="section-title-mincho service-title">あなたの場のために、オーダーメイドでセレクトします</h2>

          <div className="prose service-intro">
            <p>
              在庫から選んで当てはめることはしません。私たちが最初に見るのは、ワインではなく、あなたの店の
              <span className="service-ink-wash">「世界観」</span>です。
            </p>
          </div>

          <div className="service-inputs-shell">
            <span className="service-inputs-blot" aria-hidden="true" />
            <dl className="service-def-list">
              {definitions.map(([term, desc]) => (
                <div key={term} className="service-def-row">
                  <dt>{term}</dt>
                  <dd>{desc}</dd>
                </div>
              ))}
            </dl>
            <p className="service-inline-copy">想い… 空間… 料理… 人…</p>
          </div>

          <div className="service-result-block">
            <p className="section-kicker service-result-kicker">R E S U L T / 期 待 で き る こ と</p>
            <ul className="service-result-list">
              {results.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>

          <div className="prose service-closing">
            <p>生産者が子どものように大切に育て、人生を託してきたワインです。</p>
            <p>この店のための一本を、一緒に設計しませんか。</p>
            <p>私たちはその背景や想い、秘話を知っているからこそ、ワインの“熱量”ごと、次の表現者へつなぐ役割を担っています。</p>
          </div>

          <div className="service-cta-row">
            <a href="#contact" className="cta-button cta-button-ink">試飲の相談</a>
            <a href="#contact" className="cta-button service-cta-secondary">導入相談</a>
            <p className="service-helper-note">※ 原則1営業日以内に返信いたします</p>
          </div>
        </div>

        <figure className="service-photo-figure">
          <div className="service-photo-wrap">
            <Image
              src="/wineries/jean-stodden-new.jpg"
              alt="生産者のワイン"
              fill
              className="object-cover object-[50%_40%]"
              sizes="(min-width: 1024px) 55vw, 100vw"
            />
          </div>
          <figcaption className="service-photo-caption">
            <span className="service-caption-rule" aria-hidden="true" />
            生産者が子どものように大切に育て、人生を託してきたワインです。
          </figcaption>
        </figure>
      </div>
    </section>
  );
}
