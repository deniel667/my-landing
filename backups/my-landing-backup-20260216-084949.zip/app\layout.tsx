import type { Metadata } from 'next';
import { EB_Garamond, Kaisei_Tokumin, Noto_Sans_JP, Zen_Old_Mincho } from 'next/font/google';
import './globals.css';

const notoSans = Noto_Sans_JP({
  variable: '--font-noto-sans',
  subsets: ['latin'],
  weight: ['300', '400', '500'],
});

const zenOldMincho = Zen_Old_Mincho({
  variable: '--font-jp-display',
  subsets: ['latin'],
  weight: ['400', '500', '700', '900'],
});

const kaiseiTokumin = Kaisei_Tokumin({
  variable: '--font-jp-alt',
  subsets: ['latin'],
  weight: ['400', '500', '700', '800'],
});

const ebGaramond = EB_Garamond({
  variable: '--font-en',
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
});

export const metadata: Metadata = {
  title: 'FINDEST',
  description: 'German Wine Specialists',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className={`${notoSans.variable} ${zenOldMincho.variable} ${kaiseiTokumin.variable} ${ebGaramond.variable} antialiased`} style={{ fontFamily: 'var(--font-noto-sans)' }}>
        {children}
      </body>
    </html>
  );
}
