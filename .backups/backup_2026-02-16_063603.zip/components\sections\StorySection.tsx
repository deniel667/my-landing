﻿import Image from 'next/image';

export default function StorySection() {
  return (
    <section id="story" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-12 items-start">
        <div className="md:col-span-6 fade-in-block">
          <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-4">Story</p>
          <h2 className="font-serif text-3xl leading-tight mb-6">現場・芸術・心理・生産者との信頼。</h2>
          <div className="space-y-4 text-sm text-text-secondary leading-relaxed">
            <p>代表の現場経験と、長年の生産者との対話によってFINDESTのスタイルは形成されました。</p>
            <p>忙しい現場でも「どうすれば無理なく、伝わるのか」を軸に、導入後の運用まで設計しています。</p>
          </div>
        </div>

        <div className="md:col-span-6 fade-in-block">
          <div className="relative aspect-[24/25] w-full max-w-md mx-auto border border-line overflow-hidden bg-white">
            <Image src="/story/story-main-president.jpg" alt="FINDEST代表" fill className="object-cover" sizes="(min-width: 1024px) 34vw, (min-width: 768px) 50vw, 100vw" />
          </div>
          <div className="relative aspect-[9/2] border border-line overflow-hidden bg-white mt-4">
            <Image src="/story/story-trip-collage.jpg" alt="生産者との交流" fill className="object-cover" sizes="(min-width: 768px) 50vw, 100vw" />
          </div>
        </div>
      </div>
    </section>
  );
}
