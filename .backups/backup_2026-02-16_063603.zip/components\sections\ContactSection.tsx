﻿export default function ContactSection() {
  return (
    <section id="contact" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-3xl mx-auto">
        <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-3 text-center">Contact</p>
        <h2 className="font-serif text-3xl text-center mb-12">お問い合わせ</h2>

        <form className="space-y-8 border border-line p-6 md:p-10 bg-white/70 fade-in-block text-left">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <label className="text-xs tracking-[0.18em] text-text-secondary">
              店名 / 会社名
              <input type="text" className="mt-2 w-full border-b border-line bg-transparent py-2 focus:outline-none focus:border-accent" />
            </label>
            <label className="text-xs tracking-[0.18em] text-text-secondary">
              担当者名
              <input type="text" className="mt-2 w-full border-b border-line bg-transparent py-2 focus:outline-none focus:border-accent" />
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <label className="text-xs tracking-[0.18em] text-text-secondary">
              Email
              <input type="email" className="mt-2 w-full border-b border-line bg-transparent py-2 focus:outline-none focus:border-accent" />
            </label>
            <label className="text-xs tracking-[0.18em] text-text-secondary">
              業態
              <select className="mt-2 w-full border-b border-line bg-transparent py-2 focus:outline-none focus:border-accent">
                <option>飲食</option>
                <option>ホテル</option>
                <option>酒販</option>
              </select>
            </label>
          </div>

          <label className="text-xs tracking-[0.18em] text-text-secondary block">
            お問い合わせ内容
            <textarea rows={5} className="mt-2 w-full border-b border-line bg-transparent py-2 focus:outline-none focus:border-accent resize-none" />
          </label>

          <div className="text-center pt-6">
            <button type="submit" className="premium-btn bg-text text-bg px-12 py-4 text-[11px] uppercase tracking-[0.22em]">
              送信する <span className="arrow-motion ml-2">→</span>
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}
