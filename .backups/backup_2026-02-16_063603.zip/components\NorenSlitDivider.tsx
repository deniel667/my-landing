﻿type Props = { id?: string };

export default function NorenSlitDivider({ id }: Props) {
  return (
    <div id={id} className="noren-slit" aria-hidden="true">
      <span className="noren-slit-line" />
      <span className="noren-slit-gap" />
      <span className="noren-slit-line" />
    </div>
  );
}
