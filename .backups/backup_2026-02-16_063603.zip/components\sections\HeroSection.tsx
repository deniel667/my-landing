﻿import type { HeroData } from '@/data/my-landing/site';

type Props = { data: HeroData };

export default function HeroSection({ data }: Props) {
  return (
    <header id="hero" className="hero-gradient relative min-h-screen pt-28 pb-16 px-6 md:px-12 chapter-target">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        <div className="md:col-span-8 md:col-start-3 fade-in-block">
          <h1 className="font-serif text-3xl md:text-5xl leading-tight mb-8 text-left">
            {data.lead[0]}
            <br />
            {data.lead[1]}
            <br />
            {data.lead[2]}
          </h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-end">
            <div className="text-left">
              <p className="text-[11px] uppercase tracking-[0.28em] text-accent mb-4">{data.eyebrow}</p>
              <p className="text-sm text-text-secondary leading-relaxed">{data.sub}</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <a href="#contact" className="premium-btn inline-flex items-center justify-center px-8 py-3 bg-text text-bg text-xs tracking-[0.18em] uppercase">
                導入相談 <span className="arrow-motion ml-2">→</span>
              </a>
              <a href="#contact" className="premium-btn inline-flex items-center justify-center px-8 py-3 border border-text text-text text-xs tracking-[0.18em] uppercase">
                資料請求 <span className="arrow-motion ml-2">→</span>
              </a>
            </div>
          </div>
          <p className="mt-4 text-[10px] text-text-secondary">{data.note}</p>
        </div>
      </div>
    </header>
  );
}
