﻿import Image from 'next/image';

const wineries = [
  { id: 'dautel', name: 'Weingut Dautel', region: 'Wurttemberg', photo: '/wineries/dautel-new.jpg', imageClass: 'object-cover' },
  { id: 'horst', name: 'Weingut Horst Sauer', region: 'Franken', photo: '/wineries/horst-sauer-new.jpg', imageClass: 'object-cover' },
  { id: 'landerer', name: 'Weingut Landerer', region: 'Baden', photo: '/wineries/landerer-new.jpg', imageClass: 'object-cover' },
  { id: 'ludwig', name: 'Weingut Ludwig', region: 'Mosel', photo: '/wineries/ludwig-new.jpg', imageClass: 'object-cover' },
  { id: 'hamm', name: 'Weingut Hamm', region: 'Rheingau', photo: '/wineries/hamm-new.jpg', imageClass: 'object-cover object-[45%_30%]' },
  { id: 'bus', name: 'Weingut Bus', region: 'Pfalz', photo: '/wineries/bus-new.jpg', imageClass: 'object-cover' },
  { id: 'ress', name: 'Weingut Ress', region: 'Rheingau', photo: '/wineries/ress-new.jpg', imageClass: 'object-cover' },
  { id: 'salwey', name: 'Weingut Salwey', region: 'Baden', photo: '/wineries/salwey-new.jpg', imageClass: 'object-cover object-[50%_38%]' },
  { id: 'stodden', name: 'Weingut Jean Stodden', region: 'Ahr', photo: '/wineries/jean-stodden-new.jpg', imageClass: 'object-cover object-[50%_42%]' },
];

export default function CatalogueSection() {
  return (
    <section id="catalogue" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-7xl mx-auto">
        <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-3">Catalogue</p>
        <h2 className="font-serif text-3xl mb-10">ワイナリー一覧</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {wineries.map((winery) => (
            <article key={winery.id} className="fade-in-block border border-line bg-white overflow-hidden">
              <div className="relative aspect-[4/3] bg-surface">
                <Image src={winery.photo} alt={winery.name} fill className={winery.imageClass} sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw" />
              </div>
              <div className="p-4">
                <h3 className="font-serif text-lg leading-tight mb-2">{winery.name}</h3>
                <p className="text-[11px] uppercase tracking-[0.2em] text-text-secondary">{winery.region}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
