﻿const tiers = [
  {
    n: '1',
    title: '取扱店',
    role: 'FINDESTワインを扱う基本レイヤー。',
    posture: ['品質を丁寧に扱う', '提供温度を守る'],
    level: '推奨',
  },
  {
    n: '2',
    title: '共鳴店',
    role: '思想に共鳴し、表現を意識するレイヤー。',
    posture: ['背景を語る姿勢', '店の文脈に重ねる'],
    level: '必須',
  },
  {
    n: '3',
    title: '協働',
    role: '現場設計を共同で進めるレイヤー。',
    posture: ['提案を共同設計', '運用の再現性を持つ'],
    level: '必須',
  },
  {
    n: '4',
    title: '理念継承者',
    role: '暖簾を預かる最深レイヤー。',
    posture: ['型の継承', '継続的な育成'],
    level: '継承',
  },
] as const;

export default function NorenNetworkSection() {
  return (
    <section id="noren-network" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-6xl mx-auto">
        <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-3">Noren Network</p>
        <h2 className="font-serif text-3xl mb-10">暖簾分けの4階層</h2>

        <div className="relative pl-6 md:pl-12">
          <div className="absolute left-0 top-0 bottom-0 w-px bg-line" />
          <div className="space-y-6">
            {tiers.map((tier, idx) => (
              <article key={tier.n} className="fade-in-block border border-line bg-white/70 px-6 py-5" style={{ marginLeft: `${idx * 14}px` }}>
                <div className="flex items-center justify-between gap-4 mb-2">
                  <h3 className="font-serif text-xl">{tier.n}. {tier.title}</h3>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-accent border border-line px-2 py-1">{tier.level}</span>
                </div>
                <p className="text-sm text-text-secondary mb-3">{tier.role}</p>
                <ul className="text-sm text-text-secondary list-disc list-inside space-y-1">
                  {tier.posture.map((p) => <li key={p}>{p}</li>)}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
