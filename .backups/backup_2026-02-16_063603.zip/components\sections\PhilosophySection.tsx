﻿const chapters = [
  {
    id: 'ch-rinen',
    title: '① 理念',
    paragraphs: [
      'FINDESTと関わるすべての場には、共通する理念があります。',
      '品位と丁寧さを守ること。 そして、自分軸を尊重すること。',
      'その理念を、私たちは二つの言葉で表しています。',
    ],
  },
  {
    id: 'ch-mokuteki',
    title: '② 目的',
    paragraphs: [
      '近視眼的な消費や他人軸の評価に影響されていることに気付く。',
      '本質と向き合う姿勢を取り戻す。',
      'ワインを通した文化的姿勢の再設計を目指しています。',
    ],
  },
  {
    id: 'ch-kyomei',
    title: '③ 共鳴',
    paragraphs: ['志を持つ人、自分軸を大切にする姿勢。', 'そこに共鳴したとき、私たちはワインを重ねます。'],
  },
  {
    id: 'ch-kozo',
    title: '④ 構造',
    paragraphs: ['無秩序な拡大ではなく、関係性に応じて深度を整えていく。', '→ Structured Adaptation'],
  },
  {
    id: 'ch-noren',
    title: '⑤ 暖簾という発想',
    paragraphs: [
      '暖簾分けの発想を取り入れ、数を増やすだけではなく、型を共有する。',
      '浅い理解で価値を崩さないための「約束事」を丁寧に重ねます。',
    ],
  },
];

const relationships = [
  {
    title: '① 取扱店',
    body: 'FINDESTワインを扱ってくださる場。 既存の流儀の中にワインを重ね、型を壊さずに寄り添う関係です。',
  },
  {
    title: '② 共鳴店',
    body: '志と自分軸を持ち、場を丁寧に育てようとしている店。 共鳴はすべての起点です。',
  },
  {
    title: '③ 協働パートナー',
    body: '酒販店・問屋・イベントなど分野を越えて、審美眼とテーマ性を共有し、ワインの可能性を広げる関係です。',
  },
  {
    title: '④ 公認パートナー',
    body: '理念と世界観を理解し、四つの軸とワイン作法を実践する段階。 表現を支える構造を共に運用します。',
  },
];

export default function PhilosophySection() {
  return (
    <section id="philosophy" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
        <aside className="lg:col-span-3 lg:sticky lg:top-28 self-start text-left">
          <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-4">Philosophy</p>
          <h2 className="font-serif text-3xl mb-8">理念</h2>
          <div className="hidden lg:block border-l border-line pl-4 space-y-3 text-[12px] text-text-secondary">
            {chapters.map((chapter) => (
              <a key={chapter.id} href={`#${chapter.id}`} className="chapter-nav-item block hover:text-text">
                {chapter.title}
              </a>
            ))}
            <a href="#ch-relationships" className="chapter-nav-item block hover:text-text">FINDESTの四つの関係性</a>
          </div>
        </aside>

        <div className="lg:col-span-9 text-left">
          <div className="space-y-16 max-w-3xl">
            {chapters.map((chapter) => (
              <article key={chapter.id} id={chapter.id} className="chapter-block border-t border-line pt-8" style={{ scrollMarginTop: 120 }}>
                <h3 className="font-serif text-2xl mb-6">{chapter.title}</h3>
                <div className="space-y-4 text-sm leading-relaxed text-text-secondary">
                  {chapter.paragraphs.map((text) => (
                    <p key={text}>{text}</p>
                  ))}
                </div>
              </article>
            ))}

            <article id="ch-relationships" className="chapter-block border-t border-line pt-8" style={{ scrollMarginTop: 120 }}>
              <h3 className="font-serif text-2xl mb-6">FINDESTの四つの関係性</h3>
              <div className="space-y-8">
                {relationships.map((item) => (
                  <div key={item.title} className="border-b border-line pb-6">
                    <h4 className="font-serif text-xl mb-3">{item.title}</h4>
                    <p className="text-sm leading-relaxed text-text-secondary">{item.body}</p>
                  </div>
                ))}
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}
