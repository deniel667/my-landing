﻿export default function VoiceSection() {
  return (
    <section id="voice" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-6xl mx-auto text-left">
        <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-3">Voice</p>
        <h2 className="font-serif text-3xl mb-10">現場の声</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <blockquote className="fade-in-block border border-line bg-white p-7">
            <p className="font-serif text-lg leading-relaxed text-text">
              「導入の意図がメニュー上で伝わり、
              スタッフが無理なく説明できるようになりました。」
            </p>
            <footer className="mt-5 text-xs tracking-[0.2em] uppercase text-text-secondary">Restaurant Owner</footer>
          </blockquote>

          <blockquote className="fade-in-block border border-line bg-white p-7">
            <p className="font-serif text-lg leading-relaxed text-text">
              「単なる仕入れではなく、
              表現設計としてワインを扱えるようになっています。」
            </p>
            <footer className="mt-5 text-xs tracking-[0.2em] uppercase text-text-secondary">Hotel F&amp;B Manager</footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
}
