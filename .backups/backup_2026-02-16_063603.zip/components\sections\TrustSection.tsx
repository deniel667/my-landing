﻿export default function TrustSection() {
  return (
    <section id="trust" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-14 items-start">
        <div className="lg:col-span-5 fade-in-block">
          <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-3">Trust / 世界基準</p>
          <h2 className="font-serif text-3xl leading-tight mb-6">世界基準で評価される、ドイツ高品質ワイン</h2>
          <p className="text-6xl font-serif text-accent mb-4">0.2%</p>
          <p className="text-sm text-text-secondary leading-relaxed max-w-xl">
            取り扱い生産者の多くは、ドイツ高品質辛口ワイン協会VDPに所属。畑・収穫量・醸造・品質基準において厳格な基準を満たした生産者を中心に選定しています。
          </p>
        </div>

        <div className="lg:col-span-6 lg:col-start-7 fade-in-block">
          <div className="space-y-2 max-w-md ml-auto">
            <div className="w-1/4 mx-auto border border-line bg-surface py-4 text-center text-xs">GROSSE LAGE</div>
            <div className="w-2/4 mx-auto border border-line bg-surface py-4 text-center text-xs">ERSTE LAGE</div>
            <div className="w-3/4 mx-auto border border-line bg-surface py-4 text-center text-xs">ORTSWEIN</div>
            <div className="w-full mx-auto border border-line bg-surface py-4 text-center text-xs">GUTSWEIN</div>
          </div>
        </div>
      </div>
    </section>
  );
}
