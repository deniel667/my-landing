﻿const cards = [
  {
    title: '選定',
    text: 'ドイツ各地から品質と背景を確認し、現場で機能する構成で厳選します。',
  },
  {
    title: '安定供給',
    text: '単発提案ではなく、継続運用を前提に、供給と情報を整理して伴走します。',
  },
  {
    title: '導入支援',
    text: '現場で伝わる導入説明・提案文脈まで整え、スタッフが語れる状態を作ります。',
  },
] as const;

const axes = [
  ['想い', 'ビジョン'],
  ['空間', 'サービスの温度感'],
  ['料理', 'コースの流れ'],
  ['人', '店・スタッフ・ゲスト層'],
] as const;

export default function ServiceSection() {
  return (
    <section id="service" className="section-padding px-6 md:px-12 border-t border-line chapter-target">
      <div className="max-w-7xl mx-auto text-left">
        <p className="text-[10px] uppercase tracking-[0.3em] text-text-secondary mb-3">Procurement Support</p>
        <h2 className="font-serif text-3xl leading-tight mb-10">厳選セレクト＋安定供給＋導入サポート</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          {cards.map((card) => (
            <article key={card.title} className="fade-in-block border border-line bg-white p-6">
              <h3 className="font-serif text-xl mb-3">{card.title}</h3>
              <p className="text-sm text-text-secondary leading-relaxed">{card.text}</p>
            </article>
          ))}
        </div>

        <div className="border border-line bg-white p-6 md:p-8 fade-in-block">
          <h4 className="font-serif text-xl mb-6">提供内容</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {axes.map(([k, v]) => (
              <div key={k} className="border border-line/70 px-4 py-3">
                <p className="text-xs tracking-[0.2em] uppercase text-text-secondary mb-1">{k}</p>
                <p className="text-sm text-text-secondary">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
