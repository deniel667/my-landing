export default function FooterSection() {
  return (
    <footer className="bg-footer text-surface px-6 md:px-12 py-14 border-t border-line/20">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between gap-8">
        <div>
          <h2 className="font-serif text-xl tracking-[0.2em] mb-2">FINDEST</h2>
          <p className="text-xs text-surface/70">German Wine Specialists</p>
        </div>
        <div className="flex gap-6 text-xs text-surface/70 uppercase tracking-[0.18em]">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">Instagram</a>
        </div>
      </div>
    </footer>
  );
}
