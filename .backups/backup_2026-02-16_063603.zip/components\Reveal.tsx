﻿'use client';

import { useEffect } from 'react';

export default function Reveal() {
  useEffect(() => {
    const items = document.querySelectorAll<HTMLElement>('.fade-in-block, .chapter-block');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14 },
    );

    items.forEach((item, index) => {
      item.style.transitionDelay = `${(index % 5) * 90}ms`;
      observer.observe(item);
    });

    return () => observer.disconnect();
  }, []);

  return null;
}
